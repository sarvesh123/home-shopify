-- phpMyAdmin SQL Dump
-- version 4.4.15.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 03, 2016 at 02:59 PM
-- Server version: 5.5.46
-- PHP Version: 5.4.45

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopify`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(512) NOT NULL,
  `description` text NOT NULL,
  `vendor` varchar(512) NOT NULL,
  `type` varchar(512) NOT NULL,
  `tags` text NOT NULL,
  `image` varchar(512) NOT NULL,
  `meta_description` text NOT NULL,
  `compare_price` float NOT NULL,
  `weight` float NOT NULL,
  `quantity` int(6) NOT NULL,
  `sku` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `vendor`, `type`, `tags`, `image`, `meta_description`, `compare_price`, `weight`, `quantity`, `sku`) VALUES
(1, 'Description 25 Character', 'Consolidated Item Copy', 'Brand Long Name', 'Product Class Description', 'Keywords', 'Image Name Item', 'Description 125 Character', 0, 0, 0, 0),
(2, 'PLANNER,4.88X8,WK/MTH,DSK', 'Classic medallion design is given a twist when paired with these vibrant colors. Fun die-cut durable poly cover is great for both work and home! Monthly tabs for reference and quick navigation. Block format: open scheduling. Weekly: one week per two-page spread. Monthly: one month per two-page spread with notes space. Past and future months reference on each monthly page. Size: 4 7/8 x 8; Page Color/Theme: Vienna; Appointment Ruling: Open Scheduling; Edition Year: 2016.', 'AT-A-GLANCE', 'BOOKS, APPOINTMENT WIREBOUND', 'Vienna; Desk; Weekly; Monthly; Planner', '240129.JPG', 'Vienna Weekly/monthly Appointment Book, 4 7/8 X 8, Purple, 2016', 18.59, 0.504, 163, 0),
(3, 'PLANNER,APPT BOOK,W/M,PP', 'Classic medallion design is given a twist when paired with these vibrant colors. Fun die-cut durable poly cover is great for both work and home! Monthly tabs for reference and quick navigation. Block format: open scheduling. Weekly: one week per two-page spread. Monthly: one month per two-page spread with notes space. Past and future months reference on each monthly page. Size: 5 x 8; Page Color/Theme: Vienna; Appointment Ruling: Open Scheduling; Edition Year: 2016.', 'AT-A-GLANCE', 'BOOKS, APPOINTMENT WIREBOUND', 'Vienna; Appointment Book; Spiral; Open Closure; Weekly; Monthly', '232125.JPG', 'Vienna Weekly/monthly Appointment Book, 5 X 8, Purple, 2016', 19.79, 0.516, 131, 0),
(4, 'PLANNER,8.5X11,WK/MTH', 'Classic medallion design is given a twist when paired with these vibrant colors. Fun die-cut durable poly cover is great for both work and home! Monthly tabs for reference and quick navigation. Block format: open scheduling. Weekly: one week per two-page spread. Monthly: one month per two-page spread with notes space. Past and future months reference on each monthly page. Size: 8 1/2 x 11; Page Color/Theme: Vienna; Appointment Ruling: Open Scheduling; Edition Year: 2016.', 'AT-A-GLANCE', 'BOOKS, APPOINTMENT WIREBOUND', 'Vienna; Professional; Weekly; Monthly; Planner', '223314.JPG', 'Vienna Weekly/monthly Appointment Book, 5 X 8, Purple, 2016', 23.89, 1.139, 446, 0),
(5, 'DESK PAD,FLORAL,22X17', 'Hand-crafted paper flower designs change each month. Durable backboard for sturdy writing surface. One month per page with unruled blocks. Past and future months reference. Black, wide paper headband with eyelets; two clear corners. Size: 22 x 17; Page Color/Theme: Paper Flowers; Edition Year: 2016; Calendar Term: 12-Month (Jan.-Dec.).', 'AT-A-GLANCE', 'CALENDARS,DESK PADS AND REFILLS', 'Visual Organizer', '239036.JPG', 'Paper Flowers Desk Pad, 22 X 17, 2016', 13.39, 1.25, 14, 0),
(6, 'BOOK,WKLY,3 1/4 X 6 1/4BK', 'Compact size for your pocket or bag; plan weekly with a removable telephone/address section and refillable note pad. One week per two-page spread; block-style appointments; past, current and future months reference. Size: 3 1/4 x 6 1/4; Page Color/Theme: White; Appointment Ruling: Hourly, 8 AM to 5 PM (Mon-Fri); Edition Year: 2016.', 'AT-A-GLANCE', 'BOOKS, APPOINTMENT WIREBOUND', 'Appointment; Appointment Book; Appointment Books; Appointment Books/Refills; AT-A-GLANCE; Black; Calendar; Date Book; Refillable; Weekly; Memos; Sheets; Schedules; Reminders; Agendas; Recycled', '211441.JPG', 'Compact Weekly Appointment Book, 3 1/4 X 6 1/4, Black, 2016', 29.19, 0.268, 105, 0),
(7, 'BOOK,WKLY 3.25X6.25 ,BK', 'Sophisticated sewn cover and format design. Premium paper resists ink bleed. Features space for prioritized activities; storage pockets, and business card holders. Weekly: One week per two-page spread, ruled block-style for open scheduling; past, current and future months reference. Monthly: One month per two-page spread with unruled blocks. Removable telephone/address book. Deluxe, black simulated leather cover with concealed wire. Open scheduling. Size: 3 1/4 x 6 1/4; Page Color/Theme: White; Appointment Ruling: Open Scheduling; Edition Year: 2016.', 'AT-A-GLANCE', 'BOOKS, APPOINTMENT WIREBOUND', 'at a glance; recycled; executive; recycled executive; recycled weekly/monthly; recycled appointment book; appointment book; open scheduling; appointments', '211363.JPG', 'Executive Deluxe Weekly/monthly Appointment Book, 3 1/4 X 6 1/4, White, 2016', 33.59, 0.435, 18, 0),
(8, 'BOOK,APT PKT,N/REF,BK', 'Compact size and open space allows you to plan your week your way. One week per two-page spread; unruled block-style for open scheduling. Size: 2 1/2 x 4 1/2; Page Color/Theme: White; Appointment Ruling: Open Scheduling; Edition Year: 2016.', 'AT-A-GLANCE', 'BOOKS, APPOINTMENT WIREBOUND', 'Appointment; Appointment Book; Appointment Books; AT-A-GLANCE; Black; Calendar; Date Book; Weekly; Memos; Sheets; Schedules; Reminders; Agendas; Recycled', '211029.JPG', 'Weekly Planner, 2 1/2 X 4 1/2, Black, 2016', 13.29, 0.082, 67, 0),
(9, 'BOOK,APT MTHLY REF,BK', 'Compact design for your pocket or bag; plan monthly with a removable telephone/address and notes section. Premium paper resists ink bleed. Refillable cover for multi-year use. One month per two-page spread with unruled blocks; Monday start; past and future months reference. Separate, removable tabbed wirebound telephone/address section; separate, removable memo pad. Size: 3 1/2 x 6 1/8; Page Color/Theme: White; Appointment Ruling: Open Scheduling; Edition Year: 2016-2017.', 'AT-A-GLANCE', 'BOOKS, APPOINTMENT WIREBOUND', 'Appointment; Appointment Book; Appointment Books; AT-A-GLANCE; Black; Calendar; Date Book; Deluxe Pocket Planner; Monthly; Monthly Planner; Planner; Pocket Planner; Refillable; Memos; Sheets; Schedules; Reminders; Agendas; Recycled', '211297.JPG', 'Pocket-Size Monthly Planner, 3 1/2 X 6 1/8, White, 2016-2017', 25.69, 0.205, 140, 0),
(10, 'BOOK,APPT,WKLY,8X4.8,BK', 'Plan your week with hourly intervals. Premium paper resists ink bleed. Telephone/address section to manage your contacts. One week per two-page spread. Past, current and two future months reference as well as an untabbed Telephone/Address section. Size: 4 7/8 x 8; Page Color/Theme: White; Appointment Ruling: Hourly, 8 AM to 5 PM (Mon-Fri); Edition Year: 2016.', 'AT-A-GLANCE', 'BOOKS, APPOINTMENT WIREBOUND', 'Appointment; Appointment Book; Appointment Book Refills; Appointment Books; AT-A-GLANCE; Calendar; Date Book; Planner; Planner Refills; PlannerFolio; Planning; Refill; Refills for Appointment Books; Refills for Planners; Weekly; Black; Memos; Sheets; Schedules; Reminders; Agendas; Recycled', '211440.JPG', 'Weekly Appointment Book Ruled For Hourly Appointments, 4 7/8 X 8, Black, 2016', 18.19, 0.316, 185, 0);

-- --------------------------------------------------------

--
-- Table structure for table `read_files`
--

CREATE TABLE `read_files` (
  `id` int(11) unsigned NOT NULL,
  `name` varchar(512) NOT NULL,
  `path` varchar(512) NOT NULL,
  `records_count` int(7) unsigned DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `download_time` timestamp NULL DEFAULT NULL,
  `read_date` timestamp NULL DEFAULT NULL,
  `read_count` int(7) unsigned DEFAULT NULL,
  `shopify_posted` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `read_files`
--

INSERT INTO `read_files` (`id`, `name`, `path`, `records_count`, `created`, `download_time`, `read_date`, `read_count`, `shopify_posted`) VALUES
(4, 'new.xls', 'C:\\UniServerZ\\www\\new_prj/uploads', 10, '2016-01-03 14:37:03', '2016-01-03 09:06:53', '2016-01-03 09:07:03', 10, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `read_files`
--
ALTER TABLE `read_files`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `read_files`
--
ALTER TABLE `read_files`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
